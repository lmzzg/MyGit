const data = {
    name: 'Nliver的学习笔记-1'
};

// console.log(data);



handle(data);